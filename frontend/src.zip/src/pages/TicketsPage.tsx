import {
  Container,
  Typography,
  Card,
  CardContent,
  Button,
} from "@mui/material";

export default function TicketsPage() {
  return (
    <Container sx={{ py: 4 }}>
      <Typography variant="h3" gutterBottom>
        Tickets
      </Typography>

      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h5">1-Day Pass</Typography>
          <Typography variant="body2" gutterBottom>
            Access for one day of the festival.
          </Typography>
          <Button variant="contained" color="secondary">
            Buy Now
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardContent>
          <Typography variant="h5">Full Festival Pass</Typography>
          <Typography variant="body2" gutterBottom>
            Access for the entire event (2 days).
          </Typography>
          <Button variant="contained" color="secondary">
            Buy Now
          </Button>
        </CardContent>
      </Card>
    </Container>
  );
}
